package com.obstacleavoid.system.collision;

/**
 * Created by goran on 7/09/2016.
 */
public interface CollisionListener {

    void hitObstacle();
}
