package com.obstacleavoid.component;

import com.badlogic.ashley.core.Component;

/**
 * Created by goran on 7/09/2016.
 */
public class CleanUpComponent implements Component {
}
