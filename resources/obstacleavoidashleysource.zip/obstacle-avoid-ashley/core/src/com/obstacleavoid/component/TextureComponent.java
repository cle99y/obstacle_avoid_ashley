package com.obstacleavoid.component;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.graphics.g2d.TextureRegion;

/**
 * Created by goran on 7/09/2016.
 */
public class TextureComponent implements Component{

    public TextureRegion region;
}
