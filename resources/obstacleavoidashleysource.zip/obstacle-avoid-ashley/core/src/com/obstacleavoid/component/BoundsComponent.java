package com.obstacleavoid.component;

import com.badlogic.ashley.core.Component;
import com.badlogic.gdx.math.Circle;

/**
 * Created by goran on 5/09/2016.
 */
public class BoundsComponent implements Component {

    public Circle bounds = new Circle();
}
