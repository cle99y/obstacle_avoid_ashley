package com.obstacleavoid.component;

import com.badlogic.ashley.core.Component;

/**
 * Created by goran on 6/09/2016.
 */
public class WorldWrapComponent implements Component {
}
